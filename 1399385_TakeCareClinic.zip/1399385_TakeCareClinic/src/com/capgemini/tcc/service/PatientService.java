package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;



public class PatientService implements IPatientService{

	IPatientDAO patientDAO; 
	
	@Override
	public String addPatientDetails(PatientBean patient) throws PatientException {
		patientDAO=new PatientDAO();	
		String patientSeq;
		patientSeq= patientDAO.addPatientDetails(patient);
		return patientSeq; 
	}
	
	

	public void validatePatient(PatientBean patientBean) throws PatientException{
		List<String> validationErrors = new ArrayList<String>();

		//Validating Patient name
		if(!(isValidName(patientBean.getPatient_name()))) {
			validationErrors.add("\n Passenger Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating Age
		if(!(isValidAge(patientBean.getAge()))){
			validationErrors.add("\n Age Should be greater than 0 \n");
		}
		
		//Validating Phone Number
				if(!(isValidPhoneNumber(patientBean.getPhone()))){
					validationErrors.add("\n Phone Number Should be in 10 digit \n");
				}
				
		//Validating Description
		if(!(isValidDescription(patientBean.getDescription()))){
			validationErrors.add("\n Description Should Be Greater Than 3 Characters \n");
		}
		
		
		
		if(!validationErrors.isEmpty())
			throw new PatientException(validationErrors +"");
	}
	
	



	public boolean isValidName(String PatientName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(PatientName);
		return nameMatcher.matches();
	}
	
	private boolean isValidAge(int age) {
		return (age > 0);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	
	public boolean isValidDescription(String address){
		return (address.length() > 3);
	}
	
	
	

}
