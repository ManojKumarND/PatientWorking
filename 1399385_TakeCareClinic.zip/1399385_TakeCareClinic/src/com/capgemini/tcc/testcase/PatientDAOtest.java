package com.capgemini.tcc.testcase;

import static org.junit.Assert.assertNotNull;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;



public class PatientDAOtest {

	static PatientDAO dao;
	static PatientBean bean;
	
	@BeforeClass
	public static void initialize() {
		dao = new PatientDAO();
		bean = new PatientBean();
	}
	
	@Test
	public void testingBeanDetails() throws PatientException {
		assertNotNull(dao.addPatientDetails(bean));
	}
	
	@Test
	public void testPatientDetails() throws PatientException {

		bean.setPatient_name("PeterParker");
		bean.setPhone("9843376855");
		bean.setAge(12);
		bean.setDescription("High Fever");
		
	}
}
