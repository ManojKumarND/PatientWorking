package com.capgemini.tcc.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static IPatientService patientService = null;
	static PatientService patientServiceImpl = null;
	static Logger logger = Logger.getRootLogger();
	
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("resources//log4j.properties");
		PatientBean patientBean = null;

		String patient_id = null;
		int option = 0;
		
		while(true)
		{
			System.out.println("\n   TAKECARE CLINIC SOFTWARE ");
			System.out.println("--------------------------------\n");
			System.out.println("1.Add Patient Information ");
			System.out.println("2.Exit");
			System.out.println("--------------------------------");
			System.out.println("Select an option:");
			
			try {
				option = sc.nextInt();
				switch (option) {

				case 1:
					while (patientBean == null) {
						patientBean = populatePatientBean();	
					}
					try {
						patientServiceImpl = new PatientService();
						patient_id = patientServiceImpl.addPatientDetails(patientBean);

						System.out.println("\nPatient details has been successfully registered ");
						System.out.println("Your Patient ID is : " + patient_id + " ( Note ID for future reference)");
					    LocalDate sysdate=LocalDate.now();
						System.out.println("Yout Consultation Date : " + sysdate +"\nThank you !!!");

					} catch (PatientException patientException) {
						logger.error("exception occured", patientException);
						System.err.println("ERROR : "+ patientException.getMessage());
					} finally {
						patient_id = null;
						patientServiceImpl = null;
						patientBean = null;
					}

					break;
				
				case 2:
					System.out.print("Application exit successfull");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1 or 2]");
				
				}
			}
			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter valid credentials, try again");
			}
			
			
		}
	}

	
	
	private static PatientBean populatePatientBean() {
		Scanner s=new Scanner(System.in);
		PatientBean patientBean = new PatientBean();

		System.out.println("\n Enter Patient Details");

		System.out.println("Enter Patient name : ");
		patientBean.setPatient_name(sc.next());

		System.out.println("Enter Patient Age : ");
		patientBean.setAge(sc.nextInt());

		System.out.println("Enter Patient Phone number : ");
		patientBean.setPhone(sc.next());
		
		System.out.println("Enter Description : ");
		patientBean.setDescription(s.nextLine());

		
		
		LocalDate sysdate = LocalDate.now();
		patientBean.setConsultation_date(sysdate);
		
		patientServiceImpl = new PatientService();

		try {
			patientServiceImpl.validatePatient(patientBean);
			return patientBean;
		} catch (PatientException patientException) {
			logger.error("exception occured", patientException);
			System.err.println("Invalid data:");
			System.err.println(patientException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return patientBean;
	}
}
