create table Patient(
patient_id number primary key,
patient_name varchar2(20),
age number(3),
phone varchar2(10),
description varchar2(80),
consultation_date date);

 create sequence Patient_Id_Seq 
 start with 1000;