package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.connection.DBconnection;
import com.capgemini.tcc.exception.PatientException;

public class PatientDAO implements IPatientDAO {

	Logger logger=Logger.getRootLogger();
	public PatientDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	@Override
	public String addPatientDetails(PatientBean patient) throws PatientException {
Connection connection = DBconnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String patientID=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(PatientQueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,patient.getPatient_name());			
			preparedStatement.setInt(2,patient.getAge());
			preparedStatement.setString(3,patient.getPhone());
			preparedStatement.setString(4,patient.getDescription());			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(PatientQueryMapper.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			
			if(resultSet.next())
			{
				patientID=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new PatientException("Adding details failed ");

			}
			else
			{
				logger.info("Patient Added successfully:");
				return patientID;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new PatientException("Technical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
	}

}
