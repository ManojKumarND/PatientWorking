package com.capgemini.tcc.dao;

public interface PatientQueryMapper {

	public static final String INSERT_QUERY="INSERT INTO Patient VALUES(Patient_Id_Seq.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String PATIENTID_QUERY_SEQUENCE = "SELECT Patient_Id_Seq.CURRVAL FROM DUAL";

}
