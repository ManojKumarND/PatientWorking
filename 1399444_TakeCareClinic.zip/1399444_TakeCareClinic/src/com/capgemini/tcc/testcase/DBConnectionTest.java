package com.capgemini.tcc.testcase;
import java.sql.Connection;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.tcc.connection.DBconnection;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;


public class DBConnectionTest {
	static PatientDAO daotest;
	static Connection dbCon;

	@BeforeClass
	public static void initialise() {
		daotest = new PatientDAO();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println(" DBConnection Test Started\n");
	}

	@Test
	public void test() throws PatientException {
		Connection dbCon = DBconnection.getInstance().getConnection();
		Assert.assertNotNull(dbCon);
		if(dbCon!=null)
		{
			System.out.println("Connection Successfull..\n");
		}
	}

	@After
	public void afterEachTest() {
		System.out.println(" DBConnection Test Ended\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\tConnection Test Complete");
		daotest = null;
		dbCon = null;
	}

}
